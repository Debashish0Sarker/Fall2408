# src/train_models.py
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from catboost import CatBoostRegressor, Pool
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

LATENCY_TARGETS = ["avg_upload_ms", "p95_upload_ms", "avg_download_ms", "p95_download_ms"]
RECON_TARGET = "reconstruction_time_ms"


def load_indices(path: Path) -> np.ndarray:
    return np.array([int(x.strip()) for x in path.read_text().splitlines() if x.strip()], dtype=int)


def fit_one_model(df, feature_cols, cat_cols, y_col, train_idx, test_idx, params):
    X = df[feature_cols]
    y = df[y_col].astype(float)

    cat_idx = [feature_cols.index(c) for c in cat_cols if c in feature_cols]
    train_pool = Pool(X.iloc[train_idx], y.iloc[train_idx], cat_features=cat_idx)
    test_pool = Pool(X.iloc[test_idx], y.iloc[test_idx], cat_features=cat_idx)

    model = CatBoostRegressor(**params)
    model.fit(train_pool, eval_set=test_pool, verbose=False)

    pred = model.predict(test_pool)
    mae = float(mean_absolute_error(y.iloc[test_idx], pred))
    rmse = float(mean_squared_error(y.iloc[test_idx], pred, squared=False))
    r2 = float(r2_score(y.iloc[test_idx], pred))
    return model, {"mae": mae, "rmse": rmse, "r2": r2}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--processed_dir", default="data/processed")
    ap.add_argument("--splits_dir", default="data/splits")
    ap.add_argument("--models_dir", default="models")
    ap.add_argument("--random_state", type=int, default=42)
    args = ap.parse_args()

    processed_dir = Path(args.processed_dir)
    splits_dir = Path(args.splits_dir)
    models_dir = Path(args.models_dir)
    models_dir.mkdir(parents=True, exist_ok=True)

    meta = json.loads((processed_dir / "metadata.json").read_text())
    feature_cols = meta["feature_cols"]
    cat_cols = meta["categorical_cols"]

    df_base = pd.read_csv(processed_dir / "train_base.csv")
    train_idx = load_indices(splits_dir / "train_idx.txt")
    test_idx = load_indices(splits_dir / "test_idx.txt")

    params = dict(
        loss_function="RMSE",
        random_seed=args.random_state,
        iterations=2000,
        learning_rate=0.05,
        depth=8,
        l2_leaf_reg=3.0,
        eval_metric="RMSE",
        od_type="Iter",
        od_wait=100,
        allow_writing_files=False,
    )

    results = {
        "latency_models": {},
        "recon_model": None,
        "params": params,
        "features": feature_cols,
        "categoricals": cat_cols,
    }

    # Latency models (all rows)
    for target in LATENCY_TARGETS:
        if target not in df_base.columns:
            raise ValueError(f"Missing target in base: {target}")
        model, metrics = fit_one_model(df_base, feature_cols, cat_cols, target, train_idx, test_idx, params)
        out_path = models_dir / f"{target}.cbm"
        model.save_model(out_path)
        results["latency_models"][target] = {"model_file": str(out_path), "metrics": metrics}
        print(f"[OK] Trained {target} -> {out_path} | {metrics}")

    # Recon model (failure rows only)
    df_recon = pd.read_csv(processed_dir / "train_recon.csv")
    if len(df_recon) >= 10:
        idx = np.arange(len(df_recon))
        rng = np.random.default_rng(args.random_state)
        rng.shuffle(idx)
        cut = int(0.8 * len(idx))
        tr, te = idx[:cut], idx[cut:]

        model, metrics = fit_one_model(df_recon, feature_cols, cat_cols, RECON_TARGET, tr, te, params)
        out_path = models_dir / f"{RECON_TARGET}.cbm"
        model.save_model(out_path)
        results["recon_model"] = {"model_file": str(out_path), "metrics": metrics}
        print(f"[OK] Trained {RECON_TARGET} -> {out_path} | {metrics}")
    else:
        print("[WARN] Not enough failure rows with recon_time to train recon model (need >= 10).")
        results["recon_model"] = {"model_file": None, "metrics": None, "warning": "Not enough recon rows."}

    (models_dir / "model_info.json").write_text(json.dumps(results, indent=2))
    print(f"[OK] Wrote -> {models_dir / 'model_info.json'}")


if __name__ == "__main__":
    main()
