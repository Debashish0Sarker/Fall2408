# src/preprocessing.py
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

DROP_ALWAYS = ["run_id", "timestamp"]
WORKLOAD_ID_COL = "workload_id"

# Redundant if we keep policy_name categorical:
DROP_REDUNDANT_IF_POLICY_NAME_USED = ["ec_k", "ec_m", "storage_overhead", "efficiency"]

TARGETS = [
    "avg_upload_ms",
    "p95_upload_ms",
    "avg_download_ms",
    "p95_download_ms",
    "reconstruction_time_ms",
]

DEFAULT_CATEGORICALS = ["policy_name"]


def make_groups(df: pd.DataFrame) -> pd.Series:
    """
    Build grouping keys to reduce leakage across repeated workload contexts.
    We DO NOT group by run_id or timestamp. We also avoid policy_name in groups.
    """
    group_cols = []
    for c in [
        WORKLOAD_ID_COL,
        "file_size_mb",
        "num_objects",
        "concurrency",
        "read_ratio",
        "failure_state",
        "segment_size",
    ]:
        if c in df.columns:
            group_cols.append(c)

    if not group_cols:
        return pd.Series(df.index.astype(str), index=df.index)

    return df[group_cols].astype(str).agg("|".join, axis=1)


def constant_columns(df: pd.DataFrame, ignore_cols=None):
    ignore_cols = set(ignore_cols or [])
    out = []
    for c in df.columns:
        if c in ignore_cols:
            continue
        if df[c].nunique(dropna=False) <= 1:
            out.append(c)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/raw/dataset.csv")
    ap.add_argument("--outdir", default="data/processed")
    ap.add_argument("--splits_dir", default="data/splits")
    ap.add_argument("--test_size", type=float, default=0.2)
    ap.add_argument("--random_state", type=int, default=42)
    args = ap.parse_args()

    input_path = Path(args.input)
    outdir = Path(args.outdir)
    splits_dir = Path(args.splits_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    splits_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(input_path)

    # Basic checks
    missing_targets = [t for t in TARGETS if t not in df.columns]
    if missing_targets:
        raise ValueError(f"Missing target columns: {missing_targets}")

    # Group keys BEFORE dropping workload_id
    groups = make_groups(df)

    # Drop columns
    drop_cols = set()

    for c in DROP_ALWAYS:
        if c in df.columns:
            drop_cols.add(c)

    for c in DROP_REDUNDANT_IF_POLICY_NAME_USED:
        if c in df.columns:
            drop_cols.add(c)

    if WORKLOAD_ID_COL in df.columns:
        drop_cols.add(WORKLOAD_ID_COL)

    # Feature candidates
    feature_cols = [c for c in df.columns if c not in TARGETS and c not in drop_cols]

    # Auto-drop constant columns among features (data-driven)
    const_cols = constant_columns(df[feature_cols], ignore_cols=set(DEFAULT_CATEGORICALS))
    feature_cols = [c for c in feature_cols if c not in const_cols]

    # Build processed base dataset (keep targets too)
    df_base = df[feature_cols + TARGETS].copy()

    # Ensure categorical is string
    if "policy_name" in df_base.columns:
        df_base["policy_name"] = df_base["policy_name"].astype(str)

    base_out = outdir / "train_base.csv"
    df_base.to_csv(base_out, index=False)

    # Recon dataset: train ONLY on failure rows with recon_time present
    if "failure_state" not in df_base.columns:
        raise ValueError("failure_state column is required (for recon model gating).")

    df_recon = df_base[df_base["failure_state"] == 1].copy()
    df_recon = df_recon[~df_recon["reconstruction_time_ms"].isna()].copy()

    recon_out = outdir / "train_recon.csv"
    df_recon.to_csv(recon_out, index=False)

    # Group split for base dataset
    gss = GroupShuffleSplit(n_splits=1, test_size=args.test_size, random_state=args.random_state)
    idx = np.arange(len(df_base))

    # groups uses original df indexing; df_base kept same row order, so align via df.index
    train_idx, test_idx = next(gss.split(idx, groups=groups.iloc[: len(df_base)]))

    (splits_dir / "train_idx.txt").write_text("\n".join(map(str, train_idx)))
    (splits_dir / "test_idx.txt").write_text("\n".join(map(str, test_idx)))

    metadata = {
        "input_file": str(input_path),
        "rows_raw": int(len(df)),
        "rows_base": int(len(df_base)),
        "rows_recon": int(len(df_recon)),
        "feature_cols": feature_cols,
        "categorical_cols": [c for c in DEFAULT_CATEGORICALS if c in feature_cols],
        "targets": TARGETS,
        "dropped_cols": sorted(list(drop_cols)),
        "dropped_constant_cols": const_cols,
        "split": {"test_size": args.test_size, "random_state": args.random_state},
        "notes": [
            "policy_name kept as categorical feature",
            "ec_k/ec_m/storage_overhead/efficiency dropped as redundant",
            "workload_id dropped as feature to prevent memorization",
            "reconstruction_time_ms model trains only on failure_state==1 rows",
        ],
    }
    (outdir / "metadata.json").write_text(json.dumps(metadata, indent=2))

    print(f"[OK] Wrote {base_out}")
    print(f"[OK] Wrote {recon_out}")
    print(f"[OK] Wrote {outdir / 'metadata.json'}")
    print(f"[OK] Wrote splits -> {splits_dir}")


if __name__ == "__main__":
    main()
